#include <Rcpp.h>
using namespace Rcpp;


// [[Rcpp::export]]
NumericVector colSumsC(NumericMatrix x) {
  // Assuming matrices are compatible
  int n = x.nrow();
  int m = x.ncol();
  
  NumericVector out(m);
  
  for(int j = 0; j < m; j++){
    for(int i = 0; i < n; i++){
      out[j] = out[j] + x(i,j);
    }
  }
  return out;
}


