#include <Rcpp.h>
using namespace Rcpp;


// [[Rcpp::export]]
NumericMatrix rhoMatC(int n, double rho) {
  // Assuming matrices are compatible
  NumericMatrix out(n,n);
  
  for(int i = 0; i < n; i++){
    for(int j = 0; j < n; j++){
      out(i,j) = pow(rho, abs(i-j)); // use (i,j) not [i,j] for matrices
    }
  }
  return out;
}



