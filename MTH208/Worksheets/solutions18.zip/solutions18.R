#######################################
### Solutions to Worksheet 18
#######################################
library(Rcpp)
library(rbenchmark)

### Problem 1

# In R
EucR <- function(x, y)
{
  rtn <- sqrt(sum( (x-y)^2 )) 
  return(rtn)
}

# In C++ using Rcpp
cppFunction('double EucC(NumericVector x, NumericVector y) {
  double track = 0;
  int n = x.size();
  
  for(int i = 0; i < n; i++){
    track = track + pow( (x[i] - y[i]), 2);
  }
  track = sqrt(track);
  return track;
}
')

# EucC is much faster
x <- runif(1e4)
y <- runif(1e4)
benchmark(EucR(x, y), EucC(x, y))



### Problem 2
# function given
func <- function(vec)
{
  n <- length(vec)
  
  # for tracking sum and log
  sum.log <- 0
  log.of.vec <- numeric(length(n))
  
  # calculating logs and sum for each element
  for(i in 1:n)
  {
    log.of.vec[i] <- log(vec[i])
    sum.log <- sum.log + log.of.vec[i]
  }
  
  # fraction
  frac <- log.of.vec/sum.log
  return(frac)
}

## fast in R
func2 <- function(vec)
{
  temp <- log(vec)
  return(temp/sum(temp))
}

## in C++
cppFunction('NumericVector funcC(NumericVector vec){
double track = 0;
int n = vec.size();
NumericVector ans(n);
for(int i = 0; i< n; i++){
track = track + log(vec[i]);
}

for(int i = 0; i < n; i++){
  ans[i] = log(vec[i])/track;
}
return ans;
}
')

all.equal(func2(1:4), funcC(1:4))

# func2 and funcC are pretty close, but func2 is faster
benchmark(func(1:1e5), func2(1:1e5), funcC(1:1e5))

### I will do the next few questions 
### using sourceCpp

## Problem 3
sourceCpp("addC.cpp")
x <- matrix(1:10, ncol = 2, nrow = 5)
y <- matrix(seq(2, 20, by = 2), ncol = 2, nrow = 5)

addC(x,y)


### Problem 4

sourceCpp("colSumsC.cpp")
# testing if function works
all.equal(colSumsC(x), colSums(x))

# Making a large matrix
x <- matrix(runif(1:1e6), ncol = 1e3, nrow = 1e3)

# R is a little faster
# This is because colSums() in R is written in C/Fortran
# as it is.
benchmark(colSums(x), colSumsC(x))


### Problem 5
sourceCpp("posC.cpp")
posC(c(-4,3,-6, 7))


### Problem 6

#older functions
rho_mat_1 <- function(n, rho = .50)
{
  mat <- matrix(0, nrow = n, ncol = n)
  for(i in 1:n)
  {
    for(j in 1:n)
    {
      mat[i,j] <- rho^(abs(i-j))
    }
  }
} 

rho_mat_2 <- function(n, rho = .50)
{
  mat <- matrix(rho, nrow = n, ncol = n)
  mat <- mat^(abs(col(mat) - row(mat)))
  return(mat)
} 

sourceCpp("rhoMatC.cpp")

# checking if function is correct
all.equal(rho_mat_2(n = 100, rho = .50), rhoMatC(100, rho = .50))

# benchmarking for largish matrices
# C++ function is ~3 times faster than the fast R function
benchmark(rho_mat_1(n = 500, rho = .50), 
          rho_mat_2(n = 500, rho = .50),
          rhoMatC(n = 500, rho = .50), replications = 20)

