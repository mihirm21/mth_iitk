#include <Rcpp.h>
using namespace Rcpp;


// [[Rcpp::export]]
LogicalVector posC(NumericVector x) {
  // Assuming matrices are compatible
  int n = x.size();
  
 LogicalVector out(n);
  for(int i = 0; i < n; i++){
    out[i] = x[i] > 0;
  }
  return out;
}


