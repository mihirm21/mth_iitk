#include <Rcpp.h>
using namespace Rcpp;


// [[Rcpp::export]]
NumericMatrix addC(NumericMatrix x, NumericMatrix y) {
  // Assuming matrices are compatible
  int n = x.nrow();
  int m = y.ncol();
  
  NumericMatrix out(n,m);
  
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++){
      out(i,j) = x(i,j) + y(i,j); // use (i,j) not [i,j] for matrices
    }
  }
  return out;
}


