##Worksheet 1 problems


#Problem 1
fact <- function(n)
{
  if(n<0)
  {
    print("negative not alloowed")
  }
  else
  {
  if(n==0 || n==1)
  {
    return(1)
  }
  else
  {
    factorial <- 1
    for( i in 1:n)
    {
      factorial <- factorial * i;
    } 
    return(factorial)
  }
  }
}


#Problem2
euler <- function(n)
{
  output <- (1+1/n)^n
  return(output)
}
checkeuler <- function(n)
{
  t <- euler(n)
  u <- exp(1)-euler(n)
  print(paste("euler limit value is :",t))
  print(paste("difference from euler number is :",u))
}


#problem3
findseat <- function(rn) #rn stands for roll number
{
  seat <- read.csv("https://dvats.github.io/assets/course/mth208/seating.csv")
  for(i in 1:nrow(seat))
  {
    if(seat[i,1]==rn)
    {
      print(paste("Seat number is :",seat[i,2]))
      break
    }
  }
}
findseat(210695)


#problem4
findseat2 <- function(rn) #rn stands for roll number
{
  seat <- read.csv("/Users/pj/seating.csv")
  for(i in 1:nrow(seat))
  {
    if(seat[i,1]==rn)
    {
      print(paste("Seat number is :",seat[i,2]))
      break
    }
  }
}
findseat2(210695)
seat <- read.csv("/Users/pj/seating.csv")
head(seat)
Y21 <- subset(seat, Roll<220000)
head(Y21)
print(Y21)
