library(profvis)
profvis({
  attempts <- function(age)
  {
    count <- 0
    remain <- age # age no. of candles remain in the beginning
    while(remain > 0)
    {
      count <- count + 1
      # randomly choose any number between 1 and remain
      blow_out <- sample(1:remain, size = 1)
      remain <- remain - blow_out
    }
    return(count)
  }
  att_vec <- numeric(length = 1e4)
  for(i in 1:1e4)
  {
    att_vec[i] <- attempts(25)
  }
  att_vec <- replicate(1e4,attempts(25))
})
#replicate call sapply lapply and FUN along with attempts from background
#breaks we see in when we run e4 and not when we run e3 are clenup time taken by R
library(rbenchmark)
benchmark({
  att_vec <- numeric(length = 1e3)
  for(i in 1:1e3)
  {
    att_vec[i] <- attempts(25)
  }},
  replicate(1e3, attempts(25)), replications = 20)
#replicate function is slightly faster - case 1 e3
benchmark({
  att_vec <- numeric(length = 1e4)
  for(i in 1:1e4)
  {
    att_vec[i] <- attempts(25)
  }},
  replicate(1e4, attempts(25)), replications = 20)
#replicate function takes more time -case 2 e4
benchmark({
  att_vec <- NULL
  for(i in 1:1e4)
  {
    att_vec <- c(att_vec, attempts(25))
  }},
  replicate(1e4, attempts(25)),
  replications = 25)
# assigning memory beforehand saves time 
# allocate memory with good manners
#Problem 5
#problem 6
n <- 4
m <- 5
check_vec <- numeric(length=100)
ind <- 1
for (n in 1:10)
{
  for (m in 1:10)
  {
    mat <- matrix(nrow =n, ncol = m)
    mat[1:m*n] <- runif(m*n,0,1)
    data <- benchmark({colMeans(mat)},
                      apply(X = mat,MARGIN = 2,FUN = mean),
                      replications = 50
    )
    if (data[1,'elapsed']>data[2,'elapsed'])
    {
      check_vec[ind]=1
    }
    else
    {
      check_vec[ind]=0
    }
    ind <- ind +1
  }
}

