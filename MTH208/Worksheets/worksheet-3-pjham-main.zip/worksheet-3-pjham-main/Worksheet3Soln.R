#Problem1
#(a)

out <- rbinom(n = 1000, size = 1, prob = 0.5)
freq <- table(out)
print(paste("Number of heads : ",freq['1']))
#rbinom gives n output and for each output it tosses the coin size times with probability of succes(1) =  prob

#(b)

out <- rbinom(n = 1000, size = 1, prob = 0.3)
print(paste("Number of heads : ",sum(out)))

#Problem2
#(a)

bag <- c("Red", "Red", "Red", "Green", "Green", "Blue", "Blue")
val = sample(x = 1:7, size = 1)
print(paste("Ball drawn from bag is : ", bag[val]))

#(b)

A <- matrix(c(3, 1, -2, 4, 5, 3, -1, 2, -2), nrow = 3, ncol = 3)
r <- c(0,0,0)
for(i  in 1:3){
  
  r[i] <- norm(A[, i], type = "2")
}
r <- r/sum(r)
colNum <- sample(x <- 1:3,size = 1,prob = r)
print("chosen column is :")
print(A[ ,colNum])

#c
pt <- runif(n = 1, min = 0, max = 5)
print(paste("Dart lands on : ",pt))

#Problem3
#(a)

func <- function()
{
  sum <- 0
  count <-0
  while(sum<=1)
  {
    sum <- sum + runif(n = 1, min = 0, max = 1)
    count <- count + 1
  }
  return(count)
}

#(b)

vec <- numeric(length=1000)
for (i in 1:1000)
{
  vec[i]=func()
}

#(c)

print(paste("Average of values of vec :",sum(vec)/1000))
print(paste("Value of exp(1) :",exp(1)))

#Problem4

#(a)

blows <- function(age)
{
  bls=0
  blown=0
  while(blown<age)
  {
    blown <- blown +sample(x = 1:(age-blown), size = 1)
    bls <- bls + 1
  }
  return(bls)
}

#(b)
blowavg <- function(age)
{
  blowexp <- numeric(1000)
  for(i in 1:1000)
  {
    blowexp[i] <- blows(age)
  }
  
#(c)
  
  print(paste("Number of blows for blowing your birthday cake candles on average :", sum(blowexp)/1000))
}
blowavg(25)

#(d)

blowavg(30)

#Use probability and solve for number of blows to conclude that the
#number of blows required are actually equal to the harmonic sum
harmonic <- function(n)
{
  Hsum <- 0
  for(i in 1:n)
  {
    Hsum <- Hsum + 1/i
  }
  return(Hsum)
}

