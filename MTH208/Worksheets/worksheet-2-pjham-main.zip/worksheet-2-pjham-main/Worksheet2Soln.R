#worksheet2

#Problem1
seat <- read.csv("https://dvats.github.io/assets/course/mth208/seating.csv")
msc <- subset(seat, Roll>220000) # roll number of MSc students are of the form 22____
MscNum <- nrow(msc)
print(paste("Number of MSc students are ",MscNum))

#Problem2
cricket <- read.csv("https://dvats.github.io/assets/course/mth208/battingbowling.csv")  
data1 <- subset(cricket, Batting > 25)
ar <- subset(data1, Bowling < 40) #making a subset for All Rounders
freq <- table(ar['Team']) #making a table of frequency of teamwise allrounders
freq <- sort(freq)
freq1 <- names(freq)
print(paste("Minimum all rounders :",freq1[1]))
print(paste("Maximum all rounders :",freq1[nrow(freq)]))


#Problem3
plot(1:10,type="l")


#Problem4
n <- 1:1000
f <- (1+1/n)^n
plot(n,f,type="l")
abline(h=exp(1),col="red")
