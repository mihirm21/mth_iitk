library(tidyverse)
library(rvest)
#Problem1

html <- read_html("https://www.imdb.com/chart/top/")
name <- html_elements(html, ".titleColumn a")
name <- html_text(name)
year <- html_elements(html, ".secondaryInfo")
year <- html_text(year)
rate <- html_elements(html, ".ratingColumn")
rate <- html_elements(rate, "strong")
ratings <- html_text(rate)
vote <- html_attrs(rate) #getting names of attributes
yearVal <- substring(year,2,5) #removed brackets
yearVal <- strtoi(yearVal)  #converting to integer
ratings <- as.numeric(ratings) #converting to number
votes <- str_sub(substring(vote,14,),1,-14) #extrating no. of votes from attribute string
votes <- as.numeric(gsub(",","",votes)) #replacement of commas with null





codes <- html_elements(html, "tr td .wlb_ribbon")
codes <- html_attr(codes,"data-tconst")
codes <-paste0("https://imdb.com/title/",codes,"/ratings/")


df <- data.frame(matrix(ncol = 19, nrow = 0))
colnames(df) <-c("Rank","Name","Year","Total Votes","Fin Ratings","10","9","8","7","6","5","4","3","2","1","Men Votes","Women Votes","Men Rating","Women Rating")
for( i in 1:250)
{
  link <- codes[i]
  htmlMov <- read_html(link)
  rowVec <- numeric(0)
  rowVec <- append(rowVec,c(i,name[i],yearVal[i],votes[i],ratings[i]))
  all_ratings <- htmlMov %>% html_table()
  ratingType1 <- all_ratings[[1]]
  for( j in 1:10)
  {
    rowVec <- append(rowVec,ratingType1[j,3])
  }
  gendRating <- all_ratings[[2]]
  men <- gendRating[[2,2]]
  women <- gendRating[[3,2]]
  men <- gsub(" ","",men)
  men <- gsub("\n","",men)
  menR <- as.numeric(substring(men,1,3))
  menV <- as.numeric(gsub(",","",substring(men,3,)))
  women <- gsub(" ","",women)
  women <- gsub("\n","",women)
  womenR <- as.numeric(substring(women,1,3))
  womenV <- as.numeric(gsub(",","",substring(women,3,)))
  rowVec <- append(rowVec,c(menV,womenV,menR,womenR))
  df[nrow(df)+1,] <- rowVec
}

imgURL <- html_elements(html,"tr img")
imgURL <- html_attr(imgURL,"src")


library(imager)

prop.color <- function(img, col)
{
  col.mat <- as.array(img[,,1,])
  dims <- dim(col.mat)
  
  dist <- matrix(0, nrow = dims[1], ncol = dims[2])
  for(i in 1:dims[1])
  {
    for(j in 1:dims[2])
    {
      dist[i,j] <- norm(col.mat[i,j, ] - col, "2")
    }
  }
  
  props <- sum(dist < .2)/(dims[1]*dims[2])
  return(props)
}
proportions <- c()
for(i in 1:250)
{
  poster <- load.image(imgURL[i])
  col <- c(0,0,0)
  proportions <- append(proportions,prop.color(poster,col))
}
