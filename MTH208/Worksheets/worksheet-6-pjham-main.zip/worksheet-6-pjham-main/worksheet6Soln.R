library(tidyverse)
library(rvest)
html <- read_html("https://www.iitk.ac.in/math/faculty")
# extracting all tags with class = head3. The
# "." indicates class.
name <- html_elements(html, ".head3")
# From all the head3 class, extracting all link tags
name <- html_elements(name, "a")
# Extracting the text associated with the links
name <- html_text(name)
## A faster way
name <- html_elements(html, ".head3 a")
name <- html_text(name)
#pipes in tidyverse
name <- html %>% html_elements(".head3 a") %>% html_text()

#Problem1
html1 <- read_html("https://www.iitk.ac.in/math/visitors-post-doctoral-fellow")
name1 <- html_elements(html1, ".head2")
name1 <- html_text(name1)
print(name1)

#Problem2
html2 <- read_html("https://www.imdb.com/chart/top/")
name2 <- html_elements(html2, ".titleColumn a")
name2 <- html_text(name2)
print(name2)


#Problem3
html3 <- html2
name3 <- name2
year3 <- html_elements(html3, ".secondaryInfo")
year3 <- html_text(year3)
rate3 <- html_elements(html3, ".ratingColumn")
rate3 <- html_elements(rate3, "strong")
ratings <- html_text(rate3)
vote3 <- html_attrs(rate3) #getting names of attributes
yearVal <- substring(year3,2,5) #removed brackets
yearVal <- strtoi(yearVal)  #converting to integer
ratings <- as.numeric(ratings) #converting to number
votes <- str_sub(substring(vote3,14,),1,-14) #extrating no. of votes from attribute string
votes <- as.numeric(gsub(",","",votes)) "replacement of commas with null"
df <- data.frame(Names = name3, Ratings = ratings, Votes = votes, Year = yearVal) 
