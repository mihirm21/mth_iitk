library(imager)
dog <- load.image("dog.jpeg")
dim(dog) # stored as RGB
plot(dog) # plot image
graydog <- grayscale(dog)
plot(graydog)
dim(graydog)
# Extract the black and white image as matrix
gray.mat <- as.matrix(graydog[,,1,1])
dim(gray.mat)
# Extracts the array will all three rgb channels
col.mat <- as.array(dog[, ,1, ])
dim(col.mat)

#Problem1

col.r <- col.mat[,,1]
col.g <- col.mat[,,2]
col.b <- col.mat[,,3]
plot(dog) # plot image

#Purest Green
col.dist <- (1-col.g)^2 + col.b^2 +col.r^2 ##distance of rgb vector from pure green rgb vector
pts <- which(col.dist == min(col.dist),arr.ind = TRUE) ## collection of points at which the above distance is minimum
points(pts,type = "p",pch =16, col="red") ##pch plots a character, here 16 stands for a dot

#Purest Blue
col.dist <- (1-col.b)^2 + col.g^2 +col.r^2
pts <- which(col.dist == min(col.dist),arr.ind = TRUE)
points(pts,type = "p",pch =16, col="white")

#Purest red
col.dist <- (1-col.r)^2 + col.b^2 +col.g^2
pts <- which(col.dist == min(col.dist),arr.ind = TRUE)
points(pts,type = "p",pch =16, col="blue")

#Find primary colours
col1 <- as.array(load.image("col1.png")[,,1,])
col2 <- as.array(load.image("col2.png")[,,1,])
col3 <- as.array(load.image("col3.png")[,,1,])
for( i in 1:3)
{
  if(i ==1)
  {
    coli <- col1
  }else if(i==2)
  {
    coli <- col2
  }else if(i==3)
  {
    coli <- col3
  }
  col.r <- coli[,,1]
  col.g <- coli[,,2]
  col.b <- coli[,,3]
  col.distg <- max((1-col.g)^2 + col.b^2 +col.r^2) 
  col.distb <- max((1-col.b)^2 + col.g^2 +col.r^2)
  col.distr <- max((1-col.r)^2 + col.b^2 +col.g^2)
  min <- c(col.distg,col.distb,col.distr)
  w <-which.min(min) # index of min vector having minimum dist from a pure colour rgb
  if(w==1) ##checking that even the maximum distance from which pure vector is minimum
  {
    print(paste0("col",i," is of the colour green"))
  }
  if(w==2)
  {
    print(paste0("col",i," is of the colour blue"))
  }
  if(w==3)
  {
    print(paste0("col",i," is of the colour red"))
  }
  
}


#Snowing check
snowcheck <- function(str)
{
  img <- load.image(str)
  grayimg <- grayscale(img)
  img.mat <- as.array(grayimg[, ,1,1])
  x <- 1:nrow(img.mat)
  y <- 1:ncol(img.mat)
  
  whitecheck <- img.mat[x,y]>0.65 #check if value in each pixel is 65 percent white atlest
  s <- sum(whitecheck) #sum of true values
  i <- s/(nrow(img.mat)*ncol(img.mat)) #number of whitish pixels over total pixels
  if(i>0.6)
    return("Lot of snow")
  else
    return("Not a lot of snow")
}

snowcheck("land1.jpeg")
snowcheck("land2.jpeg")
