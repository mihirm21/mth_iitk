#######################################
### Solutions to Worksheet 19
#######################################
library(Rcpp)
library(rbencmark)
## Problem 1
# I have already done almost all of these in sourcCpp
# in the solution to Worksheet 18


## Problem 2
# code in R from Worksheet 3 solutions
attempts <- function()
{
  sums <- 0
  count <- 0
  while(sums <= 1)
  {
    sums <- sums + runif(n = 1, min = 0, max = 1)
    count <- count + 1
  }
  return(count)
}

# C++ code
sourceCpp("expCountC.cpp")
foo <- repCountC(1e4)
mean(foo) ## compare to exp(1), testing if it works

reps <- 1e4
## C++ code is ~ 14 times faster
benchmark(replicate(1e4, attempts), repCountC(reps))


## Problem 3
# function in R from Worksheet 3 solutions
attempts <- function(age)
{
  count <- 0
  remain <- age # age no. of candles remain in the beginning
  while(remain > 0)
  {
    count <- count + 1
    
    # randomly choose any number between 1 and remain
    blow_out <- sample(1:remain, size = 1)
    remain <- remain - blow_out
  }
  
  return(count)
}

# C++ version
sourceCpp("candlesC.cpp")

foo <- repCandlesC(age = 30, n = 1e3)
mean(foo)  # testing if function works

# C++ is about ~20 times faster!
benchmark(replicate(1e3, attempts(30)),  repCandlesC(age = 30, n = 1e3))



## Problem 4
sourceCpp("addArmaC.cpp")

x <- matrix(1:10, ncol = 2, nrow = 5)
y <- matrix(seq(2, 20, by = 2), ncol = 2, nrow = 5)

# checking function works
all.equal(addC(x,y), addArmaC(x,y))
x <- matrix(runif(1:1e6), ncol = 1e3, nrow = 1e3)

# armadillo is a little faster!
benchmark(addC(x,x), addArmaC(x,x))

