#include <Rcpp.h>
using namespace Rcpp;

int candles(int age){
  int remain = age;
  int att = 0;
  IntegerVector samp;  
  IntegerVector temp(1);
  while(remain > 0){
    samp = seq(1, remain);
    temp = sample(samp, 1); // sample returns a vector
    remain = remain - temp[0]; //picking up the first element
    att++;
  }
  return att;
}

// [[Rcpp::export]]
IntegerVector repCandlesC(int age, int n) {
  IntegerVector reps(n);
  
  for(int i = 0; i < n; i++)
  {
    reps[i] = candles(age);
  }
  return reps;
}


