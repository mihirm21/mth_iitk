#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
int count(){
  double sum = 0.0;
  int att = 0;
  while(sum < 1.0){
    sum = sum + R::runif(0.0, 1.0);
    att++;
  }
  return att;
}

// [[Rcpp::export]]
IntegerVector repCountC(int n) {
  IntegerVector reps(n);
  
  for(int i = 0; i < n; i++)
  {
    reps[i] = count();
  }
  return reps;
}


