// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;

// [[Rcpp::export]]
arma::mat addArmaC(arma::mat x,arma::mat y) {
  // inner product of two vectors is a matrix
  arma::mat add = x + y;
  return add;
}

// [[Rcpp::export]]
NumericMatrix addC(NumericMatrix x, NumericMatrix y) {
  // Assuming matrices are compatible
  int n = x.nrow();
  int m = y.ncol();
  
  NumericMatrix out(n,m);
  
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++){
      out(i,j) = x(i,j) + y(i,j); // use (i,j) not [i,j] for matrices
    }
  }
  return out;
}
