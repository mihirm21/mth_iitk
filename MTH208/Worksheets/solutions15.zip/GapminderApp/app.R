########################################
# App for the Gapminder dataset 
########################################
library(ggplot2)
library(gapminder)
library(shiny)


# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Gapminder Data"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
          checkboxGroupInput("continent",
                             "Choose which Continent",
                             choices = levels(gapminder$continent),
                             selected = c("Asia", "Europe")),
        sliderInput("year", "Select Years", 
                    min = min(gapminder$year),
                    max = max(gapminder$year),
                    value = c(min(gapminder$year), max(gapminder$year)),
                    step = 1),
        selectInput("count", "Select Country for Comparison",
                    choices = levels(gapminder$country),
                    selected = "France")
        ),
        # Show a plot of the generated distribution
        mainPanel(
          h3("Life Expectancy and GDP Analysis"),
          plotOutput("distPlot"),
          textOutput("top"),
          plotOutput("line")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output, session) {

    sub <- reactive({
      cont <- input$continent
      subset(gapminder, gapminder$continent %in% cont)
    })
    

    output$distPlot <- renderPlot({

        dat <- sub()
        # generate bins based on input$bins from ui.R
      p <- ggplot(dat,
        aes(x = gdpPercap, y=lifeExp, size = pop, colour = continent)
        ) +
        geom_point(show.legend = TRUE, alpha = 0.7) +
        scale_color_viridis_d() +
        scale_size(range = c(2, 12)) +
        scale_x_log10() +
        labs(x = "GDP per capita", y = "Life expectancy")
      p
    })
    
    output$top <- renderText({
      dat <- sub()
      time <- input$year
      dat <- subset(dat,  (dat$year <= time[2] & dat$year >= time[1]) )
      ind <- which.max(dat$lifeExp)
      paste("Country with the best Life Expectancy in this time period was",
                  dat[ind, ]$country, "in the year",  dat[ind, ]$year)
    })
    output$line <- renderPlot({
      
      dat <- sub()
      time <- input$year
      dat <- subset(dat,  (dat$year <= time[2] & dat$year >= time[1]) )
      foo <- subset(gapminder, gapminder$country == input$count)
      
      p <- ggplot(dat,
                  aes(year, lifeExp, group = country, color = continent)) + 
        coord_cartesian(xlim = time) +
        geom_line() +
        geom_line(aes(year, lifeExp), color = "black", size = 2, 
                  show.legend = FALSE, data = foo) + 
        labs(x = "Year", y = "Life Expectancy")
      p
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
